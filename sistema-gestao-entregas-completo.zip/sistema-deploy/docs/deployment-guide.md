# Guia de Implantação do Sistema de Gestão de Entregas

Este documento contém instruções detalhadas para implantar o Sistema de Gestão de Entregas completo, incluindo frontend, backend e banco de dados.

## Pré-requisitos

- Node.js 14.x ou superior
- NPM 6.x ou superior
- Conta no MongoDB Atlas (gratuita ou paga)
- Conta no Netlify (para implantação do frontend)
- Conta no Render (para implantação do backend)
- Git (opcional, para implantação via repositório)

## Parte 1: Configuração do Banco de Dados

Siga as instruções detalhadas no arquivo [mongodb-setup.md](mongodb-setup.md) para configurar o MongoDB Atlas.

## Parte 2: Implantação do Backend

### Opção 1: Implantação no Render via GitHub

1. Crie um repositório no GitHub para o backend
2. Faça upload dos arquivos da pasta `backend` para o repositório
3. Acesse [dashboard.render.com](https://dashboard.render.com/)
4. Clique em "New" e selecione "Web Service"
5. Conecte sua conta GitHub e selecione o repositório do backend
6. Configure o serviço:
   - Nome: `sistema-gestao-entregas-backend`
   - Runtime: `Node`
   - Build Command: `npm install`
   - Start Command: `node server.js`
7. Em "Advanced", adicione as variáveis de ambiente:
   - `MONGODB_URI`: sua string de conexão do MongoDB Atlas
   - `JWT_SECRET`: uma string secreta para assinatura de tokens (ex: `suinocultura2025secretkey`)
   - `PORT`: `8080`
   - `NODE_ENV`: `production`
8. Clique em "Create Web Service"
9. Aguarde a implantação ser concluída
10. Anote a URL do serviço (ex: `https://sistema-gestao-entregas-backend.onrender.com`)

### Opção 2: Implantação no Render via Deploy from Source Code

1. Acesse [dashboard.render.com](https://dashboard.render.com/)
2. Clique em "New" e selecione "Web Service"
3. Selecione "Deploy from Source Code"
4. Cole a URL de um repositório público temporário (ex: https://github.com/render-examples/express-hello-world)
5. Configure o serviço conforme os passos 6-10 da Opção 1
6. Após a criação do serviço, vá para a aba "Settings" > "Repository"
7. Clique em "Change Repository" e atualize para seu repositório real com o código do backend

### Verificação do Backend

Após a implantação, acesse a URL do backend seguida de `/api/status` (ex: `https://sistema-gestao-entregas-backend.onrender.com/api/status`). Você deve ver uma resposta JSON indicando que a API está online.

## Parte 3: Implantação do Frontend

### Opção 1: Implantação no Netlify via GitHub

1. Crie um repositório no GitHub para o frontend
2. Faça upload dos arquivos da pasta `frontend` para o repositório
3. Acesse [app.netlify.com](https://app.netlify.com/)
4. Clique em "New site from Git"
5. Conecte sua conta GitHub e selecione o repositório do frontend
6. Configure a implantação:
   - Build command: (deixe em branco)
   - Publish directory: `/`
7. Clique em "Deploy site"
8. Aguarde a implantação ser concluída
9. Acesse "Site settings" > "Build & deploy" > "Environment"
10. Adicione uma variável de ambiente:
    - `API_URL`: URL do backend (ex: `https://sistema-gestao-entregas-backend.onrender.com`)
11. Acione uma nova implantação em "Deploys" > "Trigger deploy"

### Opção 2: Implantação no Netlify via Upload Direto

1. Abra o arquivo `frontend/js/api.js`
2. Atualize a URL da API para apontar para o backend implantado:
   ```javascript
   const API_URL = 'https://sistema-gestao-entregas-backend.onrender.com/api';
   ```
3. Salve o arquivo
4. Comprima a pasta `frontend` em um arquivo ZIP
5. Acesse [app.netlify.com](https://app.netlify.com/)
6. Clique em "Sites" e depois em "Add new site" > "Deploy manually"
7. Arraste o arquivo ZIP para a área indicada
8. Aguarde a implantação ser concluída

### Configuração de Redirecionamento no Netlify

Para garantir que as rotas do frontend funcionem corretamente, crie um arquivo `_redirects` na raiz do projeto com o seguinte conteúdo:

```
/*    /index.html   200
```

Se você já implantou o site, vá para "Site settings" > "Build & deploy" > "Post processing" > "Asset optimization" e adicione esta regra de redirecionamento.

## Parte 4: Configuração Inicial do Sistema

Após implantar o backend e o frontend, você precisa criar o usuário administrador inicial:

1. Use uma ferramenta como Postman ou cURL para fazer uma requisição POST para:
   ```
   https://seu-backend.onrender.com/api/auth/setup
   ```
2. Isso criará um usuário administrador com as seguintes credenciais:
   - Email: `admin@bthgroup.com`
   - Senha: `admin123`
3. Acesse o frontend implantado e faça login com essas credenciais
4. Recomendamos alterar a senha do administrador após o primeiro login

## Parte 5: Verificação do Sistema Completo

Para verificar se o sistema está funcionando corretamente:

1. Acesse o frontend implantado (URL fornecida pelo Netlify)
2. Faça login com as credenciais do administrador
3. Navegue pelo sistema e teste as funcionalidades:
   - Criar, editar e excluir usuários
   - Criar, editar e excluir clientes
   - Criar, editar e excluir entregas
   - Visualizar relatórios

## Solução de Problemas

### Erro de CORS no Frontend

Se o frontend não conseguir se comunicar com o backend devido a erros de CORS:

1. Verifique se a URL do backend está correta no arquivo `api.js`
2. Confirme se o backend está configurado para aceitar requisições do domínio do frontend
3. No arquivo `server.js` do backend, verifique a configuração de CORS:
   ```javascript
   app.use(cors());
   ```

### Erro de Conexão com o Banco de Dados

Se o backend não conseguir se conectar ao MongoDB:

1. Verifique se a string de conexão está correta nas variáveis de ambiente do Render
2. Confirme se o IP do Render está na lista de IPs permitidos no MongoDB Atlas
3. Teste a conexão localmente antes de implantar

### Erro de Autenticação

Se não conseguir fazer login no sistema:

1. Verifique se a rota de setup foi executada com sucesso
2. Confirme se está usando as credenciais corretas
3. Verifique os logs do backend para identificar possíveis erros

## Manutenção e Atualizações

### Atualizando o Frontend

Para atualizar o frontend:

1. Faça as alterações necessárias nos arquivos
2. Se estiver usando GitHub, faça commit e push das alterações
3. O Netlify detectará as mudanças e implantará automaticamente
4. Se estiver usando upload direto, faça upload dos arquivos novamente

### Atualizando o Backend

Para atualizar o backend:

1. Faça as alterações necessárias nos arquivos
2. Se estiver usando GitHub, faça commit e push das alterações
3. O Render detectará as mudanças e implantará automaticamente
4. Se estiver usando upload direto, faça upload dos arquivos novamente

### Backup do Banco de Dados

Recomendamos fazer backups regulares do banco de dados:

1. No MongoDB Atlas, acesse "Backup" no menu lateral
2. Configure backups automáticos ou faça backups manuais
3. Para backups manuais, clique em "Take Snapshot"

## Considerações de Segurança

Para manter seu sistema seguro:

1. Altere a senha do administrador após a configuração inicial
2. Use senhas fortes para todos os usuários
3. Restrinja o acesso ao MongoDB Atlas apenas aos IPs necessários
4. Mantenha o `JWT_SECRET` seguro e único
5. Considere implementar HTTPS para o frontend e backend
6. Atualize regularmente as dependências para corrigir vulnerabilidades
