# Configuração do Banco de Dados MongoDB Atlas

Este documento contém instruções detalhadas para configurar o banco de dados MongoDB Atlas para o Sistema de Gestão de Entregas.

## Pré-requisitos

- Conta no MongoDB Atlas (gratuita ou paga)
- Navegador web moderno
- Conexão com a internet

## Passo 1: Criar uma conta no MongoDB Atlas

1. Acesse [https://www.mongodb.com/cloud/atlas/register](https://www.mongodb.com/cloud/atlas/register)
2. Preencha o formulário de registro com suas informações
3. Clique em "Criar conta"
4. Verifique seu e-mail e confirme sua conta

## Passo 2: Criar um novo cluster

1. Após fazer login no MongoDB Atlas, clique em "Build a Database"
2. Escolha a opção "FREE" (M0 Sandbox)
3. Selecione o provedor de nuvem (AWS, Google Cloud ou Azure) e a região mais próxima de você
4. Clique em "Create Cluster"
5. Aguarde alguns minutos enquanto o cluster é criado

## Passo 3: Configurar usuário do banco de dados

1. No menu lateral esquerdo, clique em "Database Access" sob a seção "Security"
2. Clique em "Add New Database User"
3. Escolha "Password" como método de autenticação
4. Preencha os campos:
   - Username: `dbUserSistema`
   - Password: `SuinoGestao2025` (ou escolha uma senha forte)
   - Database User Privileges: "Read and write to any database"
5. Clique em "Add User"

## Passo 4: Configurar acesso à rede

1. No menu lateral esquerdo, clique em "Network Access" sob a seção "Security"
2. Clique em "Add IP Address"
3. Para desenvolvimento, você pode escolher "Allow Access from Anywhere" (0.0.0.0/0)
   - **Nota**: Para ambientes de produção, é recomendável restringir o acesso apenas aos IPs necessários
4. Adicione uma descrição como "Sistema de Gestão de Entregas"
5. Clique em "Confirm"

## Passo 5: Obter a string de conexão

1. No menu lateral esquerdo, clique em "Database" sob a seção "Deployment"
2. Clique em "Connect" no seu cluster
3. Selecione "Connect your application"
4. Escolha "Node.js" como driver e a versão mais recente
5. Copie a string de conexão fornecida
6. Substitua `<password>` pela senha do usuário que você criou
7. Adicione o nome do banco de dados após o hostname: `.../suinocultura?retryWrites=true&w=majority`

A string de conexão final deve ser semelhante a:
```
mongodb+srv://dbUserSistema:SuinoGestao2025@cluster0.mongodb.net/suinocultura?retryWrites=true&w=majority
```

## Passo 6: Configurar o arquivo .env do backend

1. Abra o arquivo `.env` na pasta raiz do backend
2. Adicione ou atualize a variável `MONGODB_URI` com a string de conexão obtida:
   ```
   MONGODB_URI=mongodb+srv://dbUserSistema:SuinoGestao2025@cluster0.mongodb.net/suinocultura?retryWrites=true&w=majority
   JWT_SECRET=suinocultura2025secretkey
   PORT=8080
   NODE_ENV=production
   ```
3. Salve o arquivo

## Passo 7: Inicializar o banco de dados

Após configurar o MongoDB Atlas e iniciar o backend pela primeira vez, o sistema criará automaticamente as coleções necessárias no banco de dados.

Para criar o usuário administrador inicial, acesse a seguinte rota:

```
POST /api/auth/setup
```

Esta rota criará um usuário administrador com as seguintes credenciais:
- Email: admin@bthgroup.com
- Senha: admin123

**Importante**: Esta rota só pode ser acessada uma vez. Após a criação do usuário administrador, ela retornará um erro informando que a configuração inicial já foi realizada.

## Verificação da Configuração

Para verificar se a configuração do banco de dados está correta:

1. Inicie o backend
2. Verifique os logs do servidor - deve haver uma mensagem "Conectado ao MongoDB"
3. Tente fazer login com o usuário administrador criado
4. Se o login for bem-sucedido, a configuração do banco de dados está correta

## Solução de Problemas

### Erro de conexão com o MongoDB

Se você receber um erro como "MongoNetworkError: failed to connect to server":

1. Verifique se a string de conexão está correta
2. Confirme se o IP do seu servidor está na lista de IPs permitidos
3. Verifique se o usuário do banco de dados tem as permissões corretas
4. Certifique-se de que o cluster está ativo e funcionando

### Erro de autenticação

Se você receber um erro como "MongoError: Authentication failed":

1. Verifique se o nome de usuário e senha na string de conexão estão corretos
2. Confirme se o usuário tem acesso ao banco de dados especificado
3. Tente recriar o usuário do banco de dados

### Outros erros

Para outros erros, consulte a [documentação oficial do MongoDB Atlas](https://docs.atlas.mongodb.com/) ou entre em contato com o suporte do MongoDB.
